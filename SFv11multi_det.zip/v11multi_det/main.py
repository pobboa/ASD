from ultralytics import YOLO

if __name__ == '__main__':
    # 训练
    # model = YOLO(r"multimodal_models/v11/中间融合1.yaml")
    # model.train(data=r"D:\BaiduNetdiskDownload\v11multi_det\ultralytics\cfg\datasets\mydata_tow_model.yaml")

    # 验证
    model = YOLO(r"D:\BaiduNetdiskDownload\v11multi_det\runs\detect\train10\weights\best.pt")
    model.val(data=r"D:\BaiduNetdiskDownload\v11multi_det\ultralytics\cfg\datasets\mydata_tow_model.yaml",batch=2)

    # 检测
    # model = YOLO(r"多模态预训练权重.pt")
    # model.predict(source=r"datasets/llvip/images/val", save=True)  # 只需要写RGB图片的路径
