from ultralytics import YOLO

# 加载训练好的模型或者网络结构配置文件
# model = YOLO('best.pt')
model = YOLO(r'D:\BaiduNetdiskDownload\v11multi_det\multimodal_models\v11\中间融合1.yaml')
# 打印模型参数信息
print(model.info())
print(model.info(detailed=True))
